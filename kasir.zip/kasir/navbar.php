<div class="navigasi">
  <a href="?page=home">Home</a>
  <a href="?page=pesanan">Pesanan</a>
  <a href="?page=transaksi">Transaksi</a>
  <a href="?page=masakan">Masakan</a>
  <a href="?page=pengguna">Pengguna</a>
  
</div>