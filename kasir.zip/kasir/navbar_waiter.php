<div class="navigasi">
  <a href="?page=home">Home</a>
  <a href="?page=pesanan">Pesanan</a>

  
</div>