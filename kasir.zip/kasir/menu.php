<div class="card">
	<div class="card-body">
		<div class="btn-group-vertical btn-block">
			<a href="?page=Pesanan" class="btn btn-primary">Pesanan</a>
			<a href="?page=Transaki" class="btn btn-primary">Transaki</a>
			<a href="?page=Masakan" class="btn btn-primary">Masakan</a>
			<a href="?page=Pengguna" class="btn btn-primary">Pengguna</a>
			<a href="?page=Logout" class="btn btn-primary">Logout</a>
		</div>
	</div>
</div>