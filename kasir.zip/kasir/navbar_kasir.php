<div class="navigasi">
  <a href="?page=home">Home</a>
  <a href="?page=pesanan">Pesanan</a>
  <a href="?page=transaksi">Transaksi</a>
  
</div>